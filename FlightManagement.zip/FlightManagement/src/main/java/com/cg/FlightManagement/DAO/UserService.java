package com.cg.FlightManagement.DAO;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.FlightManagement.entity.*;

@Service
public class UserService {
    @Autowired
    private UserDAO userDAO;

    public User createUser(User user) {
        return userDAO.save(user);
    }

    public User findByUsername(String username) {
        return userDAO.findByUsername(username);
    }
}
