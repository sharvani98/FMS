package com.cg.FlightManagement.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cg.FlightManagement.entity.*;

public interface RouteRepository extends JpaRepository<Route, Long> {
}
