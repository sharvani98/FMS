package com.cg.FlightManagement.DAO;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.cg.FlightManagement.entity.*;

@Repository
public interface FlightDAO extends JpaRepository<Flight, Long> {
}
