package com.cg.FlightManagement.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cg.FlightManagement.entity.*;

public interface UserRepository extends JpaRepository<User, Long> {
    User findByUsername(String username);
}
