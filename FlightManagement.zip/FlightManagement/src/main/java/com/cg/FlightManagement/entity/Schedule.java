package com.cg.FlightManagement.entity;

import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
public class Schedule {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @ManyToOne
    @JoinColumn(name = "flight_id")
    private Flight flight;
    private LocalDateTime departureTime;
    private LocalDateTime arrivalTime;
	public Schedule() {
		super();
	}
	public Schedule(Long id, Flight flight, LocalDateTime departureTime, LocalDateTime arrivalTime) {
		super();
		this.id = id;
		this.flight = flight;
		this.departureTime = departureTime;
		this.arrivalTime = arrivalTime;
	}
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public Flight getFlight() {
		return flight;
	}
	public void setFlight(Flight flight) {
		this.flight = flight;
	}
	public LocalDateTime getDepartureTime() {
		return departureTime;
	}
	public void setDepartureTime(LocalDateTime departureTime) {
		this.departureTime = departureTime;
	}
	public LocalDateTime getArrivalTime() {
		return arrivalTime;
	}
	public void setArrivalTime(LocalDateTime arrivalTime) {
		this.arrivalTime = arrivalTime;
	}

    // Getters and setters
}
