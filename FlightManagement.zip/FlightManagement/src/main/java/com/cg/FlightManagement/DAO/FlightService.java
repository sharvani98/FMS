package com.cg.FlightManagement.DAO;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.FlightManagement.entity.*;

import java.util.List;

@Service
public class FlightService {
    @Autowired
    private FlightDAO flightDAO;

    public Flight addFlight(Flight flight) {
        return flightDAO.save(flight);
    }

    public List<Flight> getAllFlights() {
        return flightDAO.findAll();
    }

    public void deleteFlight(Long id) {
        flightDAO.deleteById(id);
    }
}
