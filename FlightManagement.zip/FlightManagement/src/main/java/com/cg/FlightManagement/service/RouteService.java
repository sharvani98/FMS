package com.cg.FlightManagement.service;

import com.cg.FlightManagement.entity.*;
import com.cg.FlightManagement.repositories.*;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class RouteService {
    @Autowired
    private RouteRepository routeRepository;

    public Route addRoute(Route route) {
        return routeRepository.save(route);
    }

    public List<Route> getAllRoutes() {
        return routeRepository.findAll();
    }

    public void deleteRoute(Long id) {
        routeRepository.deleteById(id);
    }
}
